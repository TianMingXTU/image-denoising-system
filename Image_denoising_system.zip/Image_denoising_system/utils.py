import cv2
import numpy as np
from torchvision.datasets import CIFAR10
from torch.utils.data import DataLoader
import torchvision.transforms as transforms

def load_image(image_path, grayscale=False):
    if grayscale:
        image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    else:
        image = cv2.imread(image_path)
    return image

def add_noise(image, noise_type, **kwargs):
    if noise_type == 'gaussian':
        mean = kwargs.get('mean', 0)
        var = kwargs.get('var', 50)
        sigma = var**0.5
        h, w = image.shape[:2]
        noise = np.random.normal(mean, sigma, (h, w))
        noisy_image = np.clip(image + noise, 0, 255)
    elif noise_type == 'salt_and_pepper':
        prob = kwargs.get('prob', 0.05)
        noisy_image = np.copy(image)
        salt = np.ceil(prob * image.size * 0.5)
        pepper = np.ceil(prob * image.size * 0.5)

        coords = [np.random.randint(0, i - 1, int(salt)) for i in image.shape]
        noisy_image[tuple(coords)] = 255

        coords = [np.random.randint(0, i - 1, int(pepper)) for i in image.shape]
        noisy_image[tuple(coords)] = 0
    else:
        raise ValueError("Unknown noise type")
    return noisy_image.astype(np.uint8)

def get_dataloader(batch_size=64, num_workers=4, train=True):
    transform = transforms.Compose([
        transforms.Grayscale(),
        transforms.ToTensor()
    ])
    dataset = CIFAR10(root='./data', train=train, transform=transform, download=True)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
    return dataloader
