import argparse
import cv2
import torch
import deep_learning_methods
import traditional_filters
import utils

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Image Denoising Project')
    parser.add_argument('--image', type=str, required=False, help='Path to input image')
    parser.add_argument('--method', type=str, required=True,
                        choices=['median', 'gaussian', 'mean', 'bilateral', 'autoencoder'],
                        help='Denoising method to use')
    parser.add_argument('--train', action='store_true', help='Train the autoencoder model on CIFAR-10 dataset')
    args = parser.parse_args()

    if args.train and args.method == 'autoencoder':
        # Set device
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        # Load CIFAR-10 dataset
        dataloader = utils.get_dataloader()

        # Initialize and train the autoencoder model
        model = deep_learning_methods.Autoencoder().to(device)
        num_epochs = 50
        learning_rate = 1e-3
        model = deep_learning_methods.train_autoencoder(model, dataloader, num_epochs, learning_rate, device)

        # Save the trained model
        torch.save(model.state_dict(), 'autoencoder_model.pth')
        print("Autoencoder model training complete and saved.")

    if args.image:
        # Load image
        image = utils.load_image(args.image, grayscale=True)

        # Add noise to the image
        noisy_image = utils.add_noise(image, 'gaussian')

        # Denoise image
        if args.method == 'median':
            denoised_image = traditional_filters.median_filter(noisy_image)
        elif args.method == 'gaussian':
            denoised_image = traditional_filters.gaussian_filter(noisy_image)
        elif args.method == 'mean':
            denoised_image = traditional_filters.mean_filter(noisy_image)
        elif args.method == 'bilateral':
            denoised_image = traditional_filters.bilateral_filter(noisy_image)
        elif args.method == 'autoencoder':
            # Load the pre-trained autoencoder model
            model = deep_learning_methods.Autoencoder()
            model.load_state_dict(torch.load('autoencoder_model.pth'))

            # Denoise the image using the autoencoder
            denoised_image = deep_learning_methods.autoencoder_denoise(noisy_image, model)

        # Save denoised image
        output_path = f"{args.image.split('.')[0]}_denoised.png"
        cv2.imwrite(output_path, denoised_image)



