import cv2

def median_filter(image, kernel_size=3):
    return cv2.medianBlur(image, kernel_size)

def gaussian_filter(image, kernel_size=3, sigma=0):
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), sigma)

def mean_filter(image, kernel_size=3):
    return cv2.blur(image, (kernel_size, kernel_size))

def bilateral_filter(image, diameter=9, sigma_color=75, sigma_space=75):
    return cv2.bilateralFilter(image, diameter, sigma_color, sigma_space)

